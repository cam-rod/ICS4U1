# Cameron Rodriguez
# April 4, 2019
# This program determines if two number are amicable based on the sum of their perfect divisors.

"""
Data Dictionary

candidate1: INT: first user inputted number to be checked if amicable
candidate2: INT: second user inputted number to be checked if amicable
perfect_divisor1: INT: a list of perfect divisors for candidate1
perfect_divisor2: INT: a list of perfect divisors for candidate1
perfect_sum1: a sum of the perfect divisors of candidate1
perfect_sum2: a sum of the perfect divisors of candidate2
i: INT: iterates through each possible perfect divisor in the candidates
j: INT: iterates through each value in perfect_divisor1 and perfect_divisor2
"""

candidate1 = 0
candidate2 = 0
perfect_divisor1 = []
perfect_divisor2 = []
perfect_sum1 = 0
perfect_sum2 = 0

while True:
    candidate1 = int(raw_input('Please enter the first number to be checked: '))
    candidate2 = int(raw_input('Please enter the second number to be checked: '))
    
    if 0 in [candidate1, candidate2]:
        # End the program
        break
    # End if 0
    
    for i in range(candidate1):
        if i == 0:
            continue
        # End if i
        
        if candidate1 % i == 0:
            perfect_divisor1.append(i)
        # End if candidate
    # End for i
    
    for i in range(candidate2):
        if i == 0:
            continue
        # End if i
        
        if candidate2 % i == 0:
            perfect_divisor2.append(i)
        # End if candidate
    # End for i
    
    for j in perfect_divisor1:
        perfect_sum1 += j
    # End for j
    
    for j in perfect_divisor2:
        perfect_sum2 += j
    #End for j
    
    if perfect_sum1 == candidate2 and perfect_sum2 == candidate1:
        print 'The numbers {} and {} are amicable numbers.'.format(candidate1, candidate2)
    else:
        print 'The numbers {} and {} are not amicable numbers.'.format(candidate1, candidate2)
    # End if perfect_sum1
# End while True