# Cameron Rodriguez
# April 4, 2019
# This program determines the cost of water usage, based on number of cubic feet used.

"""
Data Dictionary

usage: FLOAT: user inputted amount of water used
cost: FLOAT: the cost of the water used in dollars
"""

usage = 0.0
cost = 0.00

usage = float(raw_input('Please enter your water usage in cubic feet: '))

if usage == 0:
    cost = 0.00
elif usage <= 1000:
    cost = 15.00
elif usage <= 2000:
    cost = 15.00 + (0.0334 * (usage - 1000))
elif usage <= 3000:
    cost = 15.00 + (0.0334 * 1000) + (0.0421 * (usage - 2000))
else:
    cost = 15.00 + (0.0334 * 1000) + (0.0421 * (1000)) + 110.00
# End if usage

print 'The total cost to use {} cubic feet of water is ${:.2f}.'.format(usage, cost)