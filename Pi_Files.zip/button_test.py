import RPi.GPIO as g
import time

a = 0
b = 0

g.setmode(g.BOARD)
g.setwarnings(False)

g.setup(37, g.OUT)
g.setup(35, g.IN, pull_up_down=g.PUD_DOWN)
g.output(37, g.HIGH)

while True:
	if g.input(35):
		a += 1
		time.sleep(0.001)
	else:
		print(a)
		time.sleep(.01)
		if a <> 0:
			b += 1
	
	if b==100:
		b=0
		a=0
