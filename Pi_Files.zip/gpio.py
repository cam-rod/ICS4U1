import RPi.GPIO as g

def start(mode, out, read, pull):
	# Set mode
	if mode[0].lower()[0] == 'b':
		g.setmode(g.BOARD)
	else:
		g.setmode(g.BCM)
 	g.setwarnings(False)

	# Set output
	g.setup(out, g.OUT)

	# Set input if selected
	if read is not None:
		if pull.lower()[0] == 'u': # Pull up
			g.setup(read, g.IN, pull_up_down=g.PUD_UP)
		else: # Pull down
			g.setup(read, g.IN, pull_up_down=g.PUD_DOWN)

def power_on(pin):
	g.output(pin, g.HIGH)

def power_off(pin):
	g.output(pin, g.LOW)

def input(pin):
	return g.input(pin)

def cleanup():
	g.cleanup()
