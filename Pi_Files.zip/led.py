import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(18, GPIO.OUT)

while True:
    print 'what do you want to do?'
    a = int(raw_input('1 for on, 2 for off, 3 for blink 10x, 4 for quit'))

    if a is 1:
        GPIO.output(18, GPIO.HIGH)
        time.sleep(2)
    elif a is 2:
        GPIO.output(18, GPIO.LOW)
        time.sleep(2)
    elif a is 3:
        for i in range(10):
            GPIO.output(18, GPIO.HIGH)
            time.sleep(0.5)
            GPIO.output(18, GPIO.LOW)
            time.sleep(0.5)
    else:
        break