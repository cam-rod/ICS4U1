import RPi.GPIO as g
import time

g.setmode(g.BOARD)
g.setwarnings(False)

d=33
c=35
b=37
a=31

g.setup([a,b,c,d],g.OUT)

while True:
	num = int(raw_input("What number would you like to display? (enter 0 to break)\n"))
	if num == 0:
		break

	if num / 8 >= 1:
		num = num % 8
		g.output(d, g.HIGH)
	if num / 4 >= 1:
		num = num % 4
		g.output(c, g.HIGH)
	if num / 2 >= 1:
		num = num % 2
		g.output(b, g.HIGH)
	if num / 1 >= 1:
		g.output(a, g.HIGH)
	
	time.sleep(3)
	g.output([a,b,c,d], g.LOW)

g.cleanup()