# Cameron Rodriguez
# February 15, 2019
# This program adds 2 numbers, each by the number of times that it is.

"""
Data Dictionary

user_number: INT: a number the user enters
num1: INT: the first number the user inputs
num2: INT: the second number the user inputs
text1: STR: the visual form of adding num1 as many times as itself
text1: STR: the visual form of adding num1 as many times as itself
result: INT: the sum of each number times itself
"""

# This function requests a number from the user and verifies it's a number
# count: STR: indicates to the user which number to enter
# Returns the number the user entered
def get_number(count):
    while True:
        try:
            user_number = int(raw_input('Enter the {} number you would like to add: '.format(count)))
            break
        except ValueError:
            print 'That is not a number, please try again.'
            continue
        # End try/except
    # End while True
    return user_number
# End get number

print 'This program will add 2 numbers, each by a number of times of itself.'

num1 = get_number('first')
num2 = get_number('second')

# Calculate the result of the problem by adding the square power of each number
result = (num1 ** 2) + (num2 ** 2)

# Prepare the text by creating a string of the number joined by plus signs, and print the answer
text1 = '+'.join([str(num1) for i in range(num1)])
text2 = '+'.join([str(num2) for i in range(num2)])

print 'The sum of {}+{} is {}.'.format(text1, text2, result)