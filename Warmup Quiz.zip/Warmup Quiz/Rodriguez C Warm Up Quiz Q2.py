# Cameron Rodriguez
# February 15, 2019
# This program will calculate how many people will recieve money if it is split twice each time until people recieve less than $1.00.

"""
Data Dictionary

initial_money: INT: the initial amount of money the user will need to share
current_money: INT: the amount of money currently being split
people: INT: the total number of people recieving money
"""

people = 1

# Request the amount of money recieved
print 'This program will calculate how many people will recieve money, until people recieve less than $1.00.'
initial_money = int(raw_input('Enter how much money you recieved: '))
current_money = initial_money

# Split the money in half and add 1 person each time until current_money is below $1.00.
while current_money >= 1.00:
    current_money /= 2.00
    people += 1
# End while current_money

# Print the answer
print 'The ${:.2f} that you recieved will be shared among {} people, the last of whom will receieve ${:.2f}.'.format(initial_money, people, current_money)

