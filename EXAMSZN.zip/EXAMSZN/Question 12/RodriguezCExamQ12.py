# Cameron Rodriguez
# June 20, 2019
# This program will determine which people should be invited to a party

"""
Data Dictionary

friends: list: the array of numbered friends
multiples: list: the list of multiples of friends to not be invited

source: file: the file containing the number of friends and multiples to be removed
friends_int: int: the total number of friends
temp: str: stores the number of multiples, and will be deleted
"""

# This function will load the number of friends and the multiples to be removed.
# Returns an array of friends and multiples of friends to be deleted
def load_friends():
    # Load file
    with open('q12in.txt', 'r') as source:
        # Create a list of friends, numbered from 1 to friends_int
        friends_int = int(source.readline().strip('\n'))
        friends = range(1, friends_int+1)
        
        # Get an array of multiples, as integers
        temp = source.readline()
        del temp
        
        multiples = source.readlines()
        for i in range(len(multiples)):
            multiples[i] = int(multiples[i].strip('\n'))
        # End for i
    # End with open
    
    # Return list of friends and multiples
    return [friends, multiples]
# End load friends

# This function removes friends on multiples.
# friends: list: the array of numbered friends
# multiples: list: the list of multiples of friends to not be invited
# Returns final invitation list
def remove_friends(friends, multiples):
    # Begin removal loop for each multiple
    for i in range(len(multiples)):
        for j in range((len(friends) / multiples[i]), 0, -1): # Remove in reverse order
            del friends[j*multiples[i]-1]
        # End for j
    # End for i
    
    return friends
# End remove friends

# This function prints the numbers of invited friends
def print_friends(friends):
    # Print each friend on its own line
    for i in friends:
        print i
    # End for i
# End print_friends

# Create variables for friends and multiples
friends = []
multiples = []

# Get list of friends and multiples
friends, multiples = load_friends()
# Remove friends on multiples
remove_friends(friends, multiples)
# Print invited friends
print_friends(friends)
