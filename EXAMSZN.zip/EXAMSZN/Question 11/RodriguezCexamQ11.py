# Cameron Rodriguez
# June 18, 2019
# This program will determine how many trains in a series can cross a bridge.

"""
Data Dictionary

bridge_capacity: int: the maximum weight capacity of the bridge
train: list: an array of the weight of the train cars
successful_cars: int: the number of cars that can successfully cross the bridge

source: file: the opened file containing the data on the train and bridge
temp: str: holds the number of cars in the train before being discarded
checking: list: an array of the weight of up to four cars being checked for capacity on the bridge
checking_sum: int: the combined weight of all cars in checking
"""

# This function will import the data on the weight of the train cars and the bridge's capacity.
# bridge_capacity: int: the maximum weight capacity of the bridge, currently empty
# train: list: a currently empty array of the weight of the train cars
# Returns the capacity of the bridge and an array of the weight of the cars
def import_train(bridge_capacity, train):
    # Open the source file
    with open('q11in.txt', 'r') as source:
        # Get the capacity of the bridge and remove the newline character before caasting to an integer
        bridge_capacity = int(source.readline().strip('\n'))
        
        # Discard number of train cars
        temp = source.readline()
        del temp
        
        # Get weight of each train car
        train = source.readlines()
    # End with open()
    
    # Strip newlines in train and cast to integer
    for i in range(len(train)):
        train[i] = int(train[i].strip('\n'))
        if train[i] == '': # Remove any empty spaces
            del train[i]
        # End if train[i]
    # End for i
    
    # Return train and bridge data
    return [bridge_capacity, train]
# End import_train

# This function determines and returns the maxiumum number of cars
# Returns the maximum number of cars that can cross the bridge
# bridge_capacity: int: the maximum weight capacity of the bridge
# train: list: an array of the weight of the train cars
# Returns the number of cars that can cross the bridg3e
def max_cars(bridge_capacity, train):
    checking = [] # Current cars being checked
    successful_cars = 0 # Cars that have successfully crossed
    
    # Begin checking capacity
    for i in train:
        checking_sum = 0
        checking.append(i) # Add newest car
        
        if len(checking) > 4: 
            del checking[0] # Remove the car that has crossed the bridge
        # End if checking
        
        # Add wieights of all cars on bridge
        for j in checking:
            checking_sum += j
        # End for j
        
        if checking_sum > bridge_capacity: # Over capacity
            break
        else: # Another car can cross the bridge
            successful_cars += 1
        # End if checking_um
    # End for i
    
    # Return number of cars that can successfully cross the bridge
    return successful_cars 
# End max_cars

bridge_capacity = 0
train = [] 
successful_cars = 0 

# Get train and bridge data
bridge_capacity, train = import_train(bridge_capacity, train)

# Determine number of cars that can cross the bridge
successful_cars = max_cars(bridge_capacity, train)

# Print result as single integer
print successful_cars