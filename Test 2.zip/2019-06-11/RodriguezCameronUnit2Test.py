# Cameron Rodriguez
# June 11, 2019
# This program takes an input and determines the number of words typed and words per minute.

"""
Data Dictionary

text_input: file: the open file containing the text input
text: str: the text entered by the student
word_count: float: the number of words entered by the student, where a word is 5 characters long
wpm: float: the number of words typed per minute
"""

# Load text into program, without stripping newlines
with open("input.txt", 'r') as text_input:
    text = text_input.read()
# End with open()

# Determine the number of words in the file
word_count = len(text) / 5.0

# Determine the number of words typed in a minute
wpm = word_count / 5.0

# Print result
print 'The user has typed {} words.'.format(word_count)
print 'The user typed at {} words per minute.'.format(wpm)